# Coursera-HTML-CSS-and-Javascript-for-Web-Developers

This repository contains all of the source code used in the course called HTML, CSS and Javascript for Web Developers in Coursera.

![Course Completion certificate](https://github.com/siddartha19/Coursera-HTML-CSS-and-Javascript-for-Web-Developers/blob/master/Certificate.PNG)


# Assignments :

* Module-1 - Quiz 
* Module-2 - Coding
* Module-3 - Coding
* Module-4 - Coding
* Module-5 - Coding


# Outputs :

* [Module-2](https://siddartha19.github.io/Coursera-HTML-CSS-and-JavaScript-for-Web-Developers/Assignments/module-2/index.html)
* [Module-3](https://siddartha19.github.io/Coursera-HTML-CSS-and-JavaScript-for-Web-Developers/Assignments/module-3/index.html)
* [Module-4](https://siddartha19.github.io/Coursera-HTML-CSS-and-JavaScript-for-Web-Developers/Assignments/module-4/index.html)
* [Module-5](https://siddartha19.github.io/Coursera-HTML-CSS-and-JavaScript-for-Web-Developers/Assignments/module-5/index.html)
